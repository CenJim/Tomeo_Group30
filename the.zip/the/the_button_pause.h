#ifndef THE_BUTTON_PAUSE_H
#define THE_BUTTON_PAUSE_H

#include <QPushButton>

class PauseButton : public QPushButton {
public:
    PauseButton(const QString &text);
};

#endif // THE_BUTTON_PAUSE_H
