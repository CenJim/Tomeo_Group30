#ifndef THE_BUTTON_FORWARD_H
#define THE_BUTTON_FORWARD_H

#include <QPushButton>

class ForwardButton : public QPushButton {
public:
    ForwardButton(const QString &text);
};

#endif // THE_BUTTON_FORWARD_H
