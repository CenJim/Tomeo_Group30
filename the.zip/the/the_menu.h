#ifndef THE_MENU_H
#define THE_MENU_H

#include <QMenuBar>
#include <QMenu>
#include <Qt>

class TheMenu : public QMenuBar
{
private:
    QMenu *fileMenu;
    QMenu *videoMenu;
    QMenu *audioMenu;
    QMenu *toolsMenu;
    QMenu *helpMenu;

    QMenu *viewMenu = new QMenu;
    QMenu *subtitlesMenu = new QMenu;

    // fileMenu
    QAction* openfileAction;
    QAction* openmediaAction;
    QAction* openfolderAction;
    QAction* closefileAction;
    QAction* closemediaAction;
    QAction* closeallAction;
    QAction* saveAction;
    QAction* saveasAction;
    QAction* exportAction;
    QAction* shareAction;
    QAction* exitAction;
    QAction* quitAction;

    // videoMenu
    QAction* sortmediaAction;
    QAction* filtermediaAction;
    QAction* fastforwardAction;
    QAction* slowmotionAction;
    QAction* loopAction;
    QAction* exportvideoonlyAction;
    QAction* exportvideoandaudioAction;
    QAction* savevideoAction;
    QAction* savevideoasAction;
    QAction* duplicatevideoAction;

    // Audio
    QAction* muteunmutAction;
    QAction* reverberatonAction;
    QAction* exportaudioonlyAction;
    QAction* addbgmtothevideoAction;
    QAction* bgmidentifyAction;

    // Tools
    QAction* metadataAction;
    QAction* contacttheuploaderAction;
    QAction* viewAction;
    QAction* subtitlesAction;
    QAction* autoclipgenerationAction;
    QAction* editthevideoAction;
    // Tools View
    QAction* fullscreenAction;
    QAction* maximizeAction;
    QAction* minimizeAction;
    QAction* reducesizeAction;
    QAction* enlargesize;
    // Tools Subtitles
    QAction* uploadtranscriptAction;
    QAction* edittranscriptAction;
    QAction* hideshowAction;

    // Help
    QAction* helpAction;
    QAction* moreinformation;
    QAction* guideAction;
    QAction* registerAction;

public:
    TheMenu();

};

#endif
