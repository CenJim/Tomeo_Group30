#ifndef THE_BUTTON_BACK_H
#define THE_BUTTON_BACK_H

#include <QPushButton>

class BackButton : public QPushButton {
public:
    BackButton(const QString &text);
};

#endif // THE_BUTTON_BACK_H
