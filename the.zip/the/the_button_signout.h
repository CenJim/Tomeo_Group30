#ifndef THE_BUTTON_SIGNOUT_H
#define THE_BUTTON_SIGNOUT_H

#include <QPushButton>

class SignoutButton : public QPushButton {
public:
    SignoutButton(const QString &text);
};

#endif // THE_BUTTON_SIGNOUT_H
