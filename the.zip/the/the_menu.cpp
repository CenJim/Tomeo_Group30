#include"the_menu.h"

TheMenu::TheMenu()
{
    fileMenu = new QMenu("&File(F)    ");
    videoMenu = new QMenu("&Video(V)    ");
    audioMenu = new QMenu("&Audio(A)    ");
    toolsMenu = new QMenu("&Tools(T)    ");
    helpMenu = new QMenu("&Help(H)    ");

    this->addMenu(fileMenu);
    this->addMenu(videoMenu);
    this->addMenu(audioMenu);
    this->addMenu(toolsMenu);
    this->addMenu(helpMenu);

    // file   
    openfileAction = new QAction("&Open file ");
    openmediaAction = new QAction("&Open media ");
    openfolderAction = new QAction("&Open folder ");
    closefileAction = new QAction("&Close file ");
    closemediaAction = new QAction("&Close media");
    closeallAction = new QAction("&Close all");
    saveAction = new QAction("&Sace ");
    saveasAction = new QAction("&Save as ");
    exportAction = new QAction("&Export media");
    shareAction = new QAction("&Share");
    exitAction = new QAction("&Exit ");
    quitAction = new QAction("&Quit Tomeo");

    fileMenu->addAction(openfileAction);
    fileMenu->addAction(openmediaAction);
    fileMenu->addAction(openfolderAction);
    fileMenu->addSeparator();
    fileMenu->addAction(closefileAction);
    fileMenu->addAction(closemediaAction);
    fileMenu->addAction(closeallAction);
    fileMenu->addSeparator();
    fileMenu->addAction(saveAction);
    fileMenu->addAction(saveasAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exportAction);
    fileMenu->addAction(shareAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    fileMenu->addAction(quitAction);

    // Video
    sortmediaAction = new QAction("&Sort media");
    filtermediaAction = new QAction("&Filter media");
    fastforwardAction = new QAction("&Fast forward");
    slowmotionAction = new QAction("&Slow motion");
    loopAction = new QAction("&Loop");
    exportvideoonlyAction = new QAction("&Export video only");
    exportvideoandaudioAction = new QAction("&Export video and audio");
    savevideoAction = new QAction("&Save video");
    savevideoasAction = new QAction("&Save video as");
    duplicatevideoAction = new QAction("&Duplicate video");

    videoMenu->addAction(sortmediaAction);
    videoMenu->addAction(filtermediaAction);
    videoMenu->addSeparator();
    videoMenu->addAction(fastforwardAction);
    videoMenu->addAction(slowmotionAction);
    videoMenu->addAction(loopAction);
    videoMenu->addSeparator();
    videoMenu->addAction(exportvideoonlyAction);
    videoMenu->addAction(exportvideoandaudioAction);
    videoMenu->addAction(savevideoAction);
    videoMenu->addAction(savevideoasAction);
    videoMenu->addAction(duplicatevideoAction);

    // Audio
    muteunmutAction = new QAction("&Mute/Unmut");
    reverberatonAction = new QAction("&Reverberation");
    exportaudioonlyAction = new QAction("&Export audio only");
    addbgmtothevideoAction = new QAction("&Add BGM to the video");
    bgmidentifyAction = new QAction("&BGM identify");

    audioMenu->addAction(muteunmutAction);
    audioMenu->addSeparator();
    audioMenu->addAction(reverberatonAction);
    audioMenu->addSeparator();
    audioMenu->addAction(exportaudioonlyAction);
    audioMenu->addSeparator();
    audioMenu->addAction(addbgmtothevideoAction);
    audioMenu->addAction(bgmidentifyAction);

    // Tools
    metadataAction = new QAction("&Meta data");
    contacttheuploaderAction = new QAction("&Contant the upload");
    viewAction = new QAction("&View");
    subtitlesAction = new QAction("&Subtitles");
    autoclipgenerationAction = new QAction("&Auto clip generation");
    editthevideoAction = new QAction("&Edit the video");

    toolsMenu->addAction(metadataAction);
    toolsMenu->addSeparator();
    toolsMenu->addAction(contacttheuploaderAction);
    toolsMenu->addSeparator();

    // View
    toolsMenu->addAction(viewAction);
    fullscreenAction = new QAction("&Full screen");
    maximizeAction = new QAction("&Maximize");
    minimizeAction = new QAction("&Minimize");
    reducesizeAction = new QAction("&Reduce size");
    enlargesize = new QAction("&Enlarge size");

    viewMenu->addAction(fullscreenAction);
    viewMenu->addAction(maximizeAction);
    viewMenu->addAction(minimizeAction);
    viewMenu->addAction(reducesizeAction);
    viewMenu->addAction(enlargesize);

    viewAction->setMenu(viewMenu);
    toolsMenu->addMenu(viewMenu);

    toolsMenu->addSeparator();

    // View
    toolsMenu->addAction(subtitlesAction);
    uploadtranscriptAction = new QAction("&Upload transcript");
    edittranscriptAction = new QAction("&Edit transcript");
    hideshowAction = new QAction("&Hide/Show subtitles");

    subtitlesMenu->addAction(uploadtranscriptAction);
    subtitlesMenu->addAction(edittranscriptAction);
    subtitlesMenu->addAction(hideshowAction);

    subtitlesAction->setMenu(subtitlesMenu);
    toolsMenu->addMenu(subtitlesMenu);

    toolsMenu->addSeparator();
    toolsMenu->addAction(autoclipgenerationAction);
    toolsMenu->addAction(editthevideoAction);

    // Help
    helpAction = new QAction("&Help");
    moreinformation = new QAction("&More information");
    guideAction = new QAction("&Guide");
    registerAction = new QAction("&Register");

    helpMenu->addAction(helpAction);
    helpMenu->addSeparator();
    helpMenu->addAction(moreinformation);
    helpMenu->addSeparator();
    helpMenu->addAction(guideAction);
    helpMenu->addSeparator();
    helpMenu->addAction(registerAction);
}
