#ifndef THE_BUTTON_ORDER_H
#define THE_BUTTON_ORDER_H

#include <QPushButton>

class OrderButton : public QPushButton {
public:
    OrderButton(const QString &text);
};

#endif // THE_BUTTON_ORDER_H
