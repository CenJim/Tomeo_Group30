#ifndef THE_BUTTON_FILTER_H
#define THE_BUTTON_FILTER_H

#include <QPushButton>

class FilterButton : public QPushButton {
public:
    FilterButton(const QString &text);
};

#endif // THE_BUTTON_FILTER_H
