#ifndef THE_BUTTON_SORT_H
#define THE_BUTTON_SORT_H

#include <QPushButton>

class SortButton : public QPushButton {
public:
    SortButton(const QString &text);
};

#endif // THE_BUTTON_SORT_H
