#ifndef THE_BUTTON_SAVE_H
#define THE_BUTTON_SAVE_H

#include <QPushButton>

class SaveButton : public QPushButton {
public:
    SaveButton(const QString &text);
};

#endif // THE_BUTTON_SAVE_H
