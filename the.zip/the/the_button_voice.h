#ifndef THE_BUTTON_VOICE_H
#define THE_BUTTON_VOICE_H

#include <QPushButton>

class VoiceButton : public QPushButton {
public:
    VoiceButton(const QString &text);
};

#endif // THE_BUTTON_VOICE_H
