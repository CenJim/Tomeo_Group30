#ifndef THE_BUTTON_SIGNIN_H
#define THE_BUTTON_SIGNIN_H

#include <QPushButton>

class SigninButton : public QPushButton {
public:
    SigninButton(const QString &text);
};

#endif // THE_BUTTON_SIGNIN_H
