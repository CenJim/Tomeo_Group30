#ifndef THE_BUTTON_RANDOM_H
#define THE_BUTTON_RANDOM_H

#include <QPushButton>

class RandomButton : public QPushButton {
public:
    RandomButton(const QString &text);
};

#endif // THE_BUTTON_RANDOM_H
