#ifndef THE_BUTTON_SHARE_H
#define THE_BUTTON_SHARE_H

#include <QPushButton>

class ShareButton : public QPushButton {
public:
    ShareButton(const QString &text);
};

#endif // THE_BUTTON_SHARE_H
