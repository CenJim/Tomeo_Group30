#ifndef THE_BUTTON_FULLSCREEN_H
#define THE_BUTTON_FULLSCREEN_H

#include <QPushButton>

class FullscreenButton : public QPushButton {
public:
    FullscreenButton(const QString &text);
};

#endif // THE_BUTTON_FULLSCREEN_H
